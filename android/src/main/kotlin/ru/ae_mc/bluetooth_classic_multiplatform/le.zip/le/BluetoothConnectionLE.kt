package ru.ae_mc.bluetooth_classic_multiplatform

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.util.Log
import io.github.edufolly.flutterbluetoothserial.le.SerialSocket
import ru.ae_mc.bluetooth_classic_multiplatform.BluetoothConnectionBase
import ru.ae_mc.bluetooth_classic_multiplatform.BluetoothConnectionBase.OnDisconnectedCallback
import ru.ae_mc.bluetooth_classic_multiplatform.BluetoothConnectionBase.OnReadCallback
import java.io.IOException
import java.util.ArrayDeque
import java.util.UUID
import java.util.concurrent.CountDownLatch

/**
 * Kotlin port (skeleton) of BluetoothConnectionLE.java.
 * Wraps a BLE socket-like connection with connect/disconnect/write and read callbacks.
 *
 * Some internals are TODO because the original file content is truncated in the upload.
 */
class BluetoothConnectionLE(
    private val context: Context,
    private val device: BluetoothDevice,
    private val adapter: BluetoothAdapter = BluetoothAdapter.getDefaultAdapter(),
    private val onRead: OnReadCallback? = null,
    private val onDisconnected: OnDisconnectedCallback? = null, onReadCallback: OnReadCallback,
    onDisconnectedCallback: OnDisconnectedCallback
) : BluetoothConnectionBase(onReadCallback, onDisconnectedCallback) {

    enum class Connected { False, Pending, True }

    companion object {
        private const val TAG = "BluetoothConnectionLE"

        // Common UUIDs; adjust to your service/characteristic UUIDs as needed
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        val CC254X_SERVICE: UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
        val CC254X_CHAR_WRITE: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")
        val CC254X_CHAR_READ: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")
    }

    private var connected: Connected = Connected.False
    private var closing = false

    // Simple write queue to serialize writes (typical for BLE 20-byte chunks)
    private val writeQueue: ArrayDeque<ByteArray> = ArrayDeque()

    // Synchronization helper if you need blocking connect semantics
    private var connectLatch: CountDownLatch? = null

    override fun isConnected(): Boolean = connected == Connected.True

    @Throws(IOException::class)
    fun connect() {
        if (isConnected()) return
        closing = false
        // TODO: Implement actual GATT connect using device.connectGatt(context, false, callback)
        // and discover services, set notifications, etc.
        Log.d(TAG, "connect() requested (TODO: establish GATT)")
        connected = Connected.True // set true when GATT fully ready
    }

    @Throws(IOException::class)
    override fun connect(address: String) {
        if (isConnected()) {
            throw IOException("already connected")
        }
        try {
            val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            val device = bluetoothAdapter.getRemoteDevice(address)
            // println("connecting...")
            connected = Connected.Pending
            val socket = SerialSocket(context, device)

            val connectionResult = arrayOfNulls<Any>(1)
            val done = CountDownLatch(1)

            // RAINY // THINK Make sure the semantics here are the same as with the classic bluetooth
            socket.connect(object : ru.ae_mc.bluetooth_classic_multiplatform.le.SerialListener {
                override fun onSerialConnect() {
                    // println("onSerialConnect")
                    connectionResult[0] = true
                    done.countDown()
                }

                override fun onSerialConnectError(e: Exception) {
                    // println("onSerialConnectError:")
                    e.printStackTrace()
                    connectionResult[0] = e
                    done.countDown()
                    this@BluetoothConnectionLE.onDisconnected(true)
                    // CHECK byRemote? Also, should this happen on initial connection attempt?
                }

                override fun onSerialRead(data: ByteArray) {
                    this@BluetoothConnectionLE.onRead(data)
                }

                override fun onSerialRead(datas: ArrayDeque<ByteArray>) {
                    for (data in datas) {
                        this@BluetoothConnectionLE.onRead(data)
                    }
                }

                override fun onSerialIoError(e: Exception) {
                    throw RuntimeException("//DUMMY", e)
                    // THINK send connection error or what?
                }
            })

            // println("awaiting connect done...")
            done.await() // DUMMY Timeout?
            // println("...connect done")

            if (connectionResult[0] is Exception) {
                // println("with connect error")
                throw connectionResult[0] as Exception
            }
            // println("with connect success")
            this.socket = socket
            connected = Connected.True
        } catch (e: Exception) {
            // System.err.println("connection failed: " + e.message)
            try {
                disconnect() // THINK Is this correct still?
            } finally {
                throw IOException(e)
            }
        }
    }

    @Throws(IOException::class)
    override fun connect(address: String, uuid: UUID) {
        connect(address); // Ignore the uuid, not used
    }

    override fun disconnect() {
        if (!isConnected() && !closing) return
        closing = true
        // TODO: Close GATT, clean up resources
        connected = Connected.False
        onDisconnected?.onDisconnected()
        Log.d(TAG, "disconnect() completed")
    }

    @Throws(IOException::class)
    override fun write(data: ByteArray) {
        if (!isConnected()) throw IOException("not connected")
        // TODO: Split into MTU-sized chunks and write via writeCharacteristic.
        synchronized(writeQueue) {
            writeQueue.addLast(data.copyOf())
        }
        drainWriteQueue()
    }

    private fun drainWriteQueue() {
        if (!isConnected()) return
        // TODO: implement write-one-at-a-time logic using onCharacteristicWrite callback
        synchronized(writeQueue) {
            if (writeQueue.isEmpty()) return
            val next = writeQueue.removeFirst()
            Log.d(TAG, "drainWriteQueue: ${'$'}{next.size} bytes")
            // writeCharacteristic(value = next)
        }
    }

    // Call this from your GATT callback onCharacteristicChanged
    private fun handleIncoming(data: ByteArray) {
        onRead?.onRead(data)
    }
}
