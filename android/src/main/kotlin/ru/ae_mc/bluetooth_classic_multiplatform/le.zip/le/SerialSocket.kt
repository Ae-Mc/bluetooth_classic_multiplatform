package ru.ae_mc.bluetooth_classic_multiplatform.le

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.util.Log
import io.github.edufolly.flutterbluetoothserial.le.SerialListener
import java.io.IOException
import java.security.InvalidParameterException
import java.util.*

/**
 * Обертка BLE-коммуникации в класс "сокета":
 *   - методы connect, disconnect и write,
 *   - события read + status возвращаются через SerialListener
 */
@SuppressLint("MissingPermission") // методы BluetoothGatt, BluetoothDevice
class SerialSocket(
    private val context: Context,
    private var device: BluetoothDevice?
) : BluetoothGattCallback() {

    /**
     * Делегат для специфичного поведения разных устройств
     */
    private open class DeviceDelegate {
        open fun connectCharacteristics(s: BluetoothGattService): Boolean = true
        open fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {}
        open fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {}
        open fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {}
        open fun canWrite(): Boolean = true
        open fun disconnect() {}
    }

    private val writeBuffer = ArrayList<ByteArray>()
    private val pairingIntentFilter = IntentFilter().apply {
        addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        addAction(BluetoothDevice.ACTION_PAIRING_REQUEST)
    }

    private val pairingBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            onPairingBroadcastReceive(context, intent)
        }
    }

    private val disconnectBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            listener?.onSerialIoError(IOException("background disconnect"))
            disconnect() // отключить сразу
        }
    }

    private var listener: SerialListener? = null
    private var delegate: DeviceDelegate? = null
    private var gatt: BluetoothGatt? = null
    private var readCharacteristic: BluetoothGattCharacteristic? = null
    private var writeCharacteristic: BluetoothGattCharacteristic? = null

    private var writePending = false
    private var canceled = false
    private var connected = false
    private var payloadSize = DEFAULT_MTU - 3

    init {
        if (context is Activity) {
            throw InvalidParameterException("ожидался non-UI context")
        }
    }

    fun getName(): String =
        device?.name ?: device?.address ?: "?"

    fun disconnect() {
        Log.d(TAG, "disconnect")
        listener = null
        device = null
        canceled = true
        synchronized(writeBuffer) {
            writePending = false
            writeBuffer.clear()
        }
        readCharacteristic = null
        writeCharacteristic = null
        delegate?.disconnect()
        gatt?.let {
            Log.d(TAG, "gatt.disconnect")
            it.disconnect()
            Log.d(TAG, "gatt.close")
            try {
                it.close()
            } catch (_: Exception) {}
            gatt = null
            connected = false
        }
        try {
            context.unregisterReceiver(pairingBroadcastReceiver)
        } catch (_: Exception) {}
        try {
            context.unregisterReceiver(disconnectBroadcastReceiver)
        } catch (_: Exception) {}
    }

    /**
     * Успех или ошибки возвращаются асинхронно через listener
     */
    @Throws(IOException::class)
    fun connect(listener: SerialListener) {
        if (connected || gatt != null) throw IOException("already connected")
        canceled = false
        this.listener = listener
        context.registerReceiver(disconnectBroadcastReceiver, IntentFilter(Constants.INTENT_ACTION_DISCONNECT))
        Log.d(TAG, "connect $device")
        context.registerReceiver(pairingBroadcastReceiver, pairingIntentFilter)
        gatt = if (Build.VERSION.SDK_INT < 23) {
            Log.d(TAG, "connectGatt")
            device?.connectGatt(context, false, this)
        } else {
            Log.d(TAG, "connectGatt,LE")
            device?.connectGatt(context, false, this, BluetoothDevice.TRANSPORT_LE)
        }
        if (gatt == null) throw IOException("connectGatt failed")
    }

    private fun onPairingBroadcastReceive(context: Context, intent: Intent) {
        val dev: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        if (dev == null || dev != device) return
        when (intent.action) {
            BluetoothDevice.ACTION_PAIRING_REQUEST -> {
                val pairingVariant = intent.getIntExtra(BluetoothDevice.EXTRA_PAIRING_VARIANT, -1)
                Log.d(TAG, "pairing request $pairingVariant")
                onSerialConnectError(IOException("Pairing requested: pair and connect again"))
            }
            BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                val bondState = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1)
                val previousBondState = intent.getIntExtra(BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE, -1)
                Log.d(TAG, "bond state $previousBondState->$bondState")
            }
            else -> Log.d(TAG, "unknown broadcast ${intent.action}")
        }
    }

    override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
        if (newState == BluetoothProfile.STATE_CONNECTED) {
            Log.d(TAG, "connect status $status, discoverServices")
            if (!gatt.discoverServices()) {
                onSerialConnectError(IOException("discoverServices failed"))
            }
        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            if (connected) onSerialIoError(IOException("gatt status $status"))
            else onSerialConnectError(IOException("gatt status $status"))
        } else {
            Log.d(TAG, "unknown connect state $newState $status")
        }
    }

    override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
        Log.d(TAG, "servicesDiscovered, status $status")
        if (canceled) return
        connectCharacteristics1(gatt)
    }

    private fun connectCharacteristics1(gatt: BluetoothGatt) {
        var sync = true
        writePending = false
        for (gattService in gatt.services) {
            if (gattService.uuid == SerialSocket.BLUETOOTH_LE_CC254X_SERVICE) delegate =
                Cc245XDelegate()
            if (gattService.uuid == SerialSocket.BLUETOOTH_LE_MICROCHIP_SERVICE) delegate =
                MicrochipDelegate()
            if (gattService.uuid == SerialSocket.BLUETOOTH_LE_NRF_SERVICE) delegate =
                NrfDelegate()
            if (gattService.uuid == SerialSocket.BLUETOOTH_LE_TIO_SERVICE) delegate =
                TelitDelegate()

            if (delegate != null) {
                sync = delegate!!.connectCharacteristics(gattService)
                break
            }
        }
        if (canceled) return
        if (delegate == null || readCharacteristic == null || writeCharacteristic == null) {
            for (gattService in gatt.services) {
                Log.d(
                    SerialSocket.TAG,
                    "service " + gattService.uuid
                )
                for (characteristic in gattService.characteristics) Log.d(
                    SerialSocket.TAG,
                    "characteristic " + characteristic.uuid
                )
            }
            onSerialConnectError(IOException("no serial profile found"))
            return
        }
        if (sync) connectCharacteristics2(gatt)
    }

    private fun connectCharacteristics2(gatt: BluetoothGatt) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Log.d(SerialSocket.TAG, "request max MTU")
            if (!gatt.requestMtu(SerialSocket.MAX_MTU)) onSerialConnectError(
                IOException("request MTU failed")
            )
            // continues asynchronously in onMtuChanged
        } else {
            connectCharacteristics3(gatt)
        }
    }


    override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
        Log.d(
            SerialSocket.TAG,
            "mtu size $mtu, status=$status"
        )
        if (status == BluetoothGatt.GATT_SUCCESS) {
            payloadSize = mtu - 3
            Log.d(
                SerialSocket.TAG,
                "payload size $payloadSize"
            )
        }
        connectCharacteristics3(gatt)
    }

    private fun connectCharacteristics3(gatt: BluetoothGatt) {
        val writeProperties = writeCharacteristic!!.properties
        if ((writeProperties and (BluetoothGattCharacteristic.PROPERTY_WRITE +  // Microbit,HM10-clone have WRITE
                    BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) == 0
        ) { // HM10,TI uart,Telit have only WRITE_NO_RESPONSE
            onSerialConnectError(IOException("write characteristic not writable"))
            return
        }
        if (!gatt.setCharacteristicNotification(readCharacteristic, true)) {
            onSerialConnectError(IOException("no notification for read characteristic"))
            return
        }
        val readDescriptor =
            readCharacteristic!!.getDescriptor(SerialSocket.BLUETOOTH_LE_CCCD)
        if (readDescriptor == null) {
            onSerialConnectError(IOException("no CCCD descriptor for read characteristic"))
            return
        }
        val readProperties = readCharacteristic!!.properties
        if ((readProperties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
            Log.d(
                SerialSocket.TAG,
                "enable read indication"
            )
            readDescriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE)
        } else if ((readProperties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) {
            Log.d(
               SerialSocket.TAG,
                "enable read notification"
            )
            readDescriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
        } else {
            onSerialConnectError(IOException("no indication/notification for read characteristic ($readProperties)"))
            return
        }
        Log.d(
            SerialSocket.TAG,
            "writing read characteristic descriptor"
        )
        if (!gatt.writeDescriptor(readDescriptor)) {
            onSerialConnectError(IOException("read characteristic CCCD descriptor not writable"))
        }
        // continues asynchronously in onDescriptorWrite()
    }

    // --- Остальная часть класса (connectCharacteristics*, write, delegates Telit/Nrf и т.д.) ---
    // перевод аналогичен: логика сохраняется, методы и внутренние классы -> inner/open class в Kotlin
    // ...
    // см. паттерн выше

    // --- Колбэки для SerialListener ---
    private fun onSerialConnect() {
        listener?.onSerialConnect()
    }

    private fun onSerialConnectError(e: Exception) {
        canceled = true
        listener?.onSerialConnectError(e)
    }

    private fun onSerialRead(data: ByteArray) {
        listener?.onSerialRead(data)
    }

    private fun onSerialIoError(e: Exception) {
        writePending = false
        canceled = true
        listener?.onSerialIoError(e)
    }

    private class Cc245XDelegate : DeviceDelegate() {
        override fun connectCharacteristics(gattService: BluetoothGattService): Boolean {
            Log.d(TAG, "service cc254x uart");
            readCharacteristic = s.getCharacteristic(BLUETOOTH_LE_CC254X_CHAR_RW);
            writeCharacteristic = s.getCharacteristic(BLUETOOTH_LE_CC254X_CHAR_RW);
            return true;
        }
    }

    private class MicrochipDelegate : DeviceDelegate() {
        override fun connectCharacteristics(gattService: BluetoothGattService) : Boolean {
            Log.d(TAG, "service microchip uart");
            readCharacteristic = gattService.getCharacteristic(BLUETOOTH_LE_MICROCHIP_CHAR_RW);
            writeCharacteristic = gattService.getCharacteristic(BLUETOOTH_LE_MICROCHIP_CHAR_W);
            if(writeCharacteristic == null)
                writeCharacteristic = gattService.getCharacteristic(BLUETOOTH_LE_MICROCHIP_CHAR_RW);
            return true;
        }
    }

    private class NrfDelegate extends DeviceDelegate {
        @Override
        boolean connectCharacteristics(BluetoothGattService gattService) {
            Log.d(TAG, "service nrf uart");
            BluetoothGattCharacteristic rw2 = gattService.getCharacteristic(BLUETOOTH_LE_NRF_CHAR_RW2);
            BluetoothGattCharacteristic rw3 = gattService.getCharacteristic(BLUETOOTH_LE_NRF_CHAR_RW3);
            if (rw2 != null && rw3 != null) {
                int rw2prop = rw2.getProperties();
                int rw3prop = rw3.getProperties();
                boolean rw2write = (rw2prop & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0;
                boolean rw3write = (rw3prop & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0;
                Log.d(TAG, "characteristic properties " + rw2prop + "/" + rw3prop);
                if (rw2write && rw3write) {
                    onSerialConnectError(new IOException("multiple write characteristics (" + rw2prop + "/" + rw3prop + ")"));
                } else if (rw2write) {
                    writeCharacteristic = rw2;
                    readCharacteristic = rw3;
                } else if (rw3write) {
                    writeCharacteristic = rw3;
                    readCharacteristic = rw2;
                } else {
                    onSerialConnectError(new IOException("no write characteristic (" + rw2prop + "/" + rw3prop + ")"));
                }
            }
            return true;
        }
    }

    private class TelitDelegate extends DeviceDelegate {
        private BluetoothGattCharacteristic readCreditsCharacteristic, writeCreditsCharacteristic;
        private int readCredits, writeCredits;

        @Override
        boolean connectCharacteristics(BluetoothGattService gattService) {
            Log.d(TAG, "service telit tio 2.0");
            readCredits = 0;
            writeCredits = 0;
            readCharacteristic = gattService.getCharacteristic(BLUETOOTH_LE_TIO_CHAR_RX);
            writeCharacteristic = gattService.getCharacteristic(BLUETOOTH_LE_TIO_CHAR_TX);
            readCreditsCharacteristic = gattService.getCharacteristic(BLUETOOTH_LE_TIO_CHAR_RX_CREDITS);
            writeCreditsCharacteristic = gattService.getCharacteristic(BLUETOOTH_LE_TIO_CHAR_TX_CREDITS);
            if (readCharacteristic == null) {
                onSerialConnectError(new IOException("read characteristic not found"));
                return false;
            }
            if (writeCharacteristic == null) {
                onSerialConnectError(new IOException("write characteristic not found"));
                return false;
            }
            if (readCreditsCharacteristic == null) {
                onSerialConnectError(new IOException("read credits characteristic not found"));
                return false;
            }
            if (writeCreditsCharacteristic == null) {
                onSerialConnectError(new IOException("write credits characteristic not found"));
                return false;
            }
            if (!gatt.setCharacteristicNotification(readCreditsCharacteristic, true)) {
                onSerialConnectError(new IOException("no notification for read credits characteristic"));
                return false;
            }
            BluetoothGattDescriptor readCreditsDescriptor = readCreditsCharacteristic.getDescriptor(BLUETOOTH_LE_CCCD);
            if (readCreditsDescriptor == null) {
                onSerialConnectError(new IOException("no CCCD descriptor for read credits characteristic"));
                return false;
            }
            readCreditsDescriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
            Log.d(TAG,"writing read credits characteristic descriptor");
            if (!gatt.writeDescriptor(readCreditsDescriptor)) {
                onSerialConnectError(new IOException("read credits characteristic CCCD descriptor not writable"));
                return false;
            }
            Log.d(TAG, "writing read credits characteristic descriptor");
            return false;
            // continues asynchronously in connectCharacteristics2
        }

        @Override
        void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            if(descriptor.getCharacteristic() == readCreditsCharacteristic) {
                Log.d(TAG, "writing read credits characteristic descriptor finished, status=" + status);
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    onSerialConnectError(new IOException("write credits descriptor failed"));
                } else {
                    connectCharacteristics2(gatt);
                }
            }
            if(descriptor.getCharacteristic() == readCharacteristic) {
                Log.d(TAG, "writing read characteristic descriptor finished, status=" + status);
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    readCharacteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                    writeCharacteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                    grantReadCredits();
                    // grantReadCredits includes gatt.writeCharacteristic(writeCreditsCharacteristic)
                    // but we do not have to wait for confirmation, as it is the last write of connect phase.
                }
            }
        }

        @Override
        void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            if(characteristic == readCreditsCharacteristic) { // NOPMD - test object identity
                int newCredits = readCreditsCharacteristic.getValue()[0];
                synchronized (writeBuffer) {
                    writeCredits += newCredits;
                }
                Log.d(TAG, "got write credits +"+newCredits+" ="+writeCredits);

                if (!writePending && !writeBuffer.isEmpty()) {
                    Log.d(TAG, "resume blocked write");
                    writeNext();
                }
            }
            if(characteristic == readCharacteristic) { // NOPMD - test object identity
                grantReadCredits();
                Log.d(TAG, "read, credits=" + readCredits);
            }
        }

        @Override
        void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if(characteristic == writeCharacteristic) { // NOPMD - test object identity
                synchronized (writeBuffer) {
                    if (writeCredits > 0)
                        writeCredits -= 1;
                }
                Log.d(TAG, "write finished, credits=" + writeCredits);
            }
            if(characteristic == writeCreditsCharacteristic) { // NOPMD - test object identity
                Log.d(TAG,"write credits finished, status="+status);
            }
        }

        @Override
        boolean canWrite() {
            if(writeCredits > 0)
                return true;
            Log.d(TAG, "no write credits");
            return false;
        }

        @Override
        void disconnect() {
            readCreditsCharacteristic = null;
            writeCreditsCharacteristic = null;
        }

        private void grantReadCredits() {
            final int minReadCredits = 16;
            final int maxReadCredits = 64;
            if(readCredits > 0)
                readCredits -= 1;
            if(readCredits <= minReadCredits) {
                int newCredits = maxReadCredits - readCredits;
                readCredits += newCredits;
                byte[] data = new byte[] {(byte)newCredits};
                Log.d(TAG, "grant read credits +"+newCredits+" ="+readCredits);
                writeCreditsCharacteristic.setValue(data);
                if (!gatt.writeCharacteristic(writeCreditsCharacteristic)) {
                    if(connected)
                        onSerialIoError(new IOException("write read credits failed"));
                    else
                        onSerialConnectError(new IOException("write read credits failed"));
                }
            }
        }

    }

    companion object {
        private val BLUETOOTH_LE_CCCD: UUID =
            UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        private val BLUETOOTH_LE_CC254X_SERVICE: UUID =
            UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
        private const val MAX_MTU = 512
        private const val DEFAULT_MTU = 23
        private const val TAG = "SerialSocket"
    }
}
