package io.github.edufolly.flutterbluetoothserial.le

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.result.ActivityResultLauncher
import androidx.fragment.app.Fragment

/**
 * Kotlin port (skeleton) of BluetoothUtil.java.
 * Provides helpers around permissions and device sorting/representation.
 */
object BluetoothUtil {

    data class Device(val device: BluetoothDevice, val name: String?) : Comparable<Device> {
        override fun compareTo(other: Device): Int {
            val thisValid = !name.isNullOrEmpty()
            val otherValid = !other.name.isNullOrEmpty()
            return when {
                thisValid && otherValid -> {
                    val n = name!!.compareTo(other.name!!)
                    if (n != 0) n else device.address.compareTo(other.device.address)
                }
                thisValid -> -1
                otherValid -> 1
                else -> device.address.compareTo(other.device.address)
            }
        }
    }

    // Example of permission array depending on API
    fun requiredPermissionsForScan(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        } else {
            @Suppress("DEPRECATION")
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }

    fun hasAllPermissions(fragment: Fragment, perms: Array<String>): Boolean =
        perms.all { fragment.requireContext().checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    fun requestPermissions(launcher: ActivityResultLauncher<Array<String>>, perms: Array<String>) {
        launcher.launch(perms)
    }

    fun showEnableLocationDialog(fragment: Fragment, onOk: (() -> Unit)? = null) {
        AlertDialog.Builder(fragment.requireContext())
            .setTitle("Location required")
            .setMessage("Scanning for Bluetooth devices requires location permission on this Android version.")
            .setPositiveButton(android.R.string.ok) { _: DialogInterface, _: Int -> onOk?.invoke() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    @SuppressLint("InlinedApi")
    fun openAppSettings(fragment: Fragment) {
        val intent = Intent(
            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${'$'}{fragment.requireContext().packageName}")
        )
        fragment.startActivity(intent)
    }
}
